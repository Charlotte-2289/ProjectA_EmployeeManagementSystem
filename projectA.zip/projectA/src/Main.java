

import javafx.application.Application;
import javafx.stage.Stage;
import controller.PayRollController;

public class Main extends Application {

    @Override
    public void start(Stage stage) {
        PayRollController controller = new PayRollController();
        controller.start(stage);
    }

    public static void main(String[] args) {
        launch(args);
    }
}

