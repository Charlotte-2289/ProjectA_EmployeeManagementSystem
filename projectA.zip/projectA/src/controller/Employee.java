package controller;

import java.io.Serializable;

public abstract class Employee implements Serializable {
    protected String id;
    protected String name;
    protected double baseSalary;

    public Employee(String id, String name, double baseSalary) {
        this.id = id;
        this.name = name;
        this.baseSalary = baseSalary;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public double getBaseSalary() { return baseSalary; }

    public abstract double calculateSalary();

    @Override
    public String toString() {
        return id + "," + name + "," + baseSalary + "," + calculateSalary();
    }
}

