package controller;



import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;


import java.io.*;
import java.util.*;

public class PayRollController {
    private ObservableList<Employee> employees = FXCollections.observableArrayList();
    private final String FILE_PATH = "data/employees.txt";
    private TableView<Employee> table;

    public void start(Stage stage) {
        VBox root = new VBox(15);
        root.setPadding(new Insets(15));

        Label title = new Label(" Employee Payroll System");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        table = new TableView<>();
        TableColumn<Employee, String> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getId()));
        TableColumn<Employee, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getName()));
        TableColumn<Employee, String> salaryCol = new TableColumn<>("Salary");
        salaryCol.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(String.valueOf(data.getValue().calculateSalary())));

        table.getColumns().addAll(idCol, nameCol, salaryCol);
        table.setItems(employees);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        Button addFullTimeBtn = new Button("Add Full-Time Employee");
        addFullTimeBtn.setOnAction(e -> addFullTimeEmployee());

        Button addPartTimeBtn = new Button("Add Part-Time Employee");
        addPartTimeBtn.setOnAction(e -> addPartTimeEmployee());

        Button saveBtn = new Button("Save to File");
        saveBtn.setOnAction(e -> saveToFile());

        Button loadBtn = new Button(" Load Data");
        loadBtn.setOnAction(e -> loadFromFile());

        HBox buttons = new HBox(10, addFullTimeBtn, addPartTimeBtn, saveBtn, loadBtn);
        buttons.setPadding(new Insets(10, 0, 0, 0));

        root.getChildren().addAll(title, table, buttons);

        Scene scene = new Scene(root, 700, 500);
        stage.setTitle("Employee Payroll System");
        stage.setScene(scene);
        stage.show();
    }

    private void addFullTimeEmployee() {
        Dialog<Employee> dialog = new Dialog<>();
        dialog.setTitle("Add Full-Time Employee");

        GridPane grid = createFormGrid();
        TextField idField = new TextField();
        TextField nameField = new TextField();
        TextField baseField = new TextField();
        TextField bonusField = new TextField();

        grid.addRow(0, new Label("ID:"), idField);
        grid.addRow(1, new Label("Name:"), nameField);
        grid.addRow(2, new Label("Base Salary:"), baseField);
        grid.addRow(3, new Label("Bonus:"), bonusField);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(button -> {
            if (button == ButtonType.OK) {
                return new FullTimeEmployee(idField.getText(), nameField.getText(),
                        Double.parseDouble(baseField.getText()), Double.parseDouble(bonusField.getText()));
            }
            return null;
        });

        dialog.showAndWait().ifPresent(emp -> employees.add(emp));
    }

    private void addPartTimeEmployee() {
        Dialog<Employee> dialog = new Dialog<>();
        dialog.setTitle("Add Part-Time Employee");

        GridPane grid = createFormGrid();
        TextField idField = new TextField();
        TextField nameField = new TextField();
        TextField baseField = new TextField();
        TextField hoursField = new TextField();
        TextField rateField = new TextField();

        grid.addRow(0, new Label("ID:"), idField);
        grid.addRow(1, new Label("Name:"), nameField);
        grid.addRow(2, new Label("Base Salary:"), baseField);
        grid.addRow(3, new Label("Hours Worked:"), hoursField);
        grid.addRow(4, new Label("Hourly Rate:"), rateField);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(button -> {
            if (button == ButtonType.OK) {
                return new PartTimeEmployee(idField.getText(), nameField.getText(),
                        Double.parseDouble(baseField.getText()),
                        Integer.parseInt(hoursField.getText()), Double.parseDouble(rateField.getText()));
            }
            return null;
        });

        dialog.showAndWait().ifPresent(emp -> employees.add(emp));
    }

    private GridPane createFormGrid() {
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10));
        return grid;
    }

    private void saveToFile() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Employee e : employees) {
                bw.write(e.toString());
                bw.newLine();
            }
            showAlert(" Data saved successfully!");
        } catch (IOException e) {
            showAlert(" Error saving data: " + e.getMessage());
        }
    }

    private void loadFromFile() {
        employees.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                String id = data[0];
                String name = data[1];
                double base = Double.parseDouble(data[2]);
                double calculated = Double.parseDouble(data[3]);
                String type = data[4];

                if (type.equals("FullTime")) {
                    employees.add(new FullTimeEmployee(id, name, base, calculated - base));
                } else if (type.equals("PartTime")) {
                    employees.add(new PartTimeEmployee(id, name, base, 0, 0));
                }
            }
            showAlert(" Data loaded successfully!");
        } catch (IOException e) {
            showAlert(" No existing data found!");
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, message);
        alert.showAndWait();
    }
}
