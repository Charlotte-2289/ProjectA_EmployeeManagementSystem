package controller;

public class PartTimeEmployee extends Employee {
    private int hoursWorked;
    private double hourlyRate;

    public PartTimeEmployee(String id, String name, double baseSalary, int hoursWorked, double hourlyRate) {
        super(id, name, baseSalary);
        this.hoursWorked = hoursWorked;
        this.hourlyRate = hourlyRate;
    }

    public int getHoursWorked() { return hoursWorked; }
    public double getHourlyRate() { return hourlyRate; }

    @Override
    public double calculateSalary() {
        return baseSalary + (hoursWorked * hourlyRate);
    }

    @Override
    public String toString() {
        return super.toString() + ",PartTime";
    }
}
